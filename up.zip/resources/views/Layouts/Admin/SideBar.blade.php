<!-- begin::side menu -->
<div class="side-menu">
 <div class="side-menu-body">
     <ul>
         <li class="side-menu-divider">فهرست</li>
         <li><a class="active" href="#"><i class="icon ti-home"></i> <span>داشبورد</span> </a></li>
            <li><a href="#"><i class="icon ti-user"></i> <span>مدارس</span> </a>
                <ul>
                    <li><a href="{{route('Admin.SchoolsList')}}">لیست مدارس</a></li>
                    <li><a href=" {{route('Admin.SchoolAdd')}} ">ثبت نام </a></li>
                </ul>
            </li>
  
        </ul>
    </div>
</div>
<!-- end::side menu -->
