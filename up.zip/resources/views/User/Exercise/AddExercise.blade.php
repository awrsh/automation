@extends('Layouts.Pannel.Template')
@section('content')

@endsection