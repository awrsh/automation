<!-- begin::navbar -->
<nav class="navbar">
 <div class="container-fluid">

     <div class="header-logo">
         <a href="#">
         <img src="<?php echo e(route('BaseUrl')); ?>/Pannel/assets/media/image/light-logo.png" alt="...">
             <span class="logo-text d-none d-lg-block"> المینو</span>
         </a>
     </div>

     <div class="header-body">
         <ul class="navbar-nav">
             <li class="nav-item dropdown d-none d-lg-block">
                 
                 
             </li>
         </ul>
         
         <ul class="navbar-nav">
             <li class="nav-item">
                 <a href="#" class="d-lg-none d-sm-block nav-link search-panel-open">
                     <i class="fa fa-search"></i>
                 </a>
             </li>
             
             

             
             <li class="nav-item d-lg-none d-sm-block">
                 <a href="#" class="nav-link side-menu-open">
                     <i class="ti-menu"></i>
                 </a>
             </li> 
         </ul>
     </div>

 </div>
</nav>
<!-- end::navbar --><?php /**PATH C:\xampp\htdocs\automation\resources\views/Layouts/Pannel/NavBar.blade.php ENDPATH**/ ?>