<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PersonelModel extends Model
{
    //
}
