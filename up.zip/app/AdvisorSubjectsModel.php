<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdvisorSubjectsModel extends Model
{
    //
}
