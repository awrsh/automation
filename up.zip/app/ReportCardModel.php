<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReportCardModel extends Model
{
    //
}
