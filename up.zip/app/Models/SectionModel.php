<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SectionModel extends Model
{
    protected $table = 'sections';
    protected $guarded = 'section_id';

    
}
