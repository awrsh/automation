<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class PasswordListSchoolModel extends Model
{
    protected $table ="password_list";
    protected $guarded = [];
}
