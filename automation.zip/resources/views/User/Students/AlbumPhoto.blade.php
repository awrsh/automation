@extends('Layouts.Pannel.Template');

@section('content')
   
<div class="container">
 <div class="row">
  <div class=" col-md-12">
    
   <div class="card">
    <div class="card-body">
        <h5 class="card-title">  آلبوم عکس دانش آموزی </h5>
        <ul class="nav nav-pills mb-3" id="pills-tab2" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="pills-all-tab" data-toggle="pill" href="#pills-all" role="tab" aria-controls="pills-home" aria-selected="true">همه کلاس ها</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="pills-eight1-tab" data-toggle="pill" href="#pills-eight1" role="tab" aria-controls="pills-profile" aria-selected="false">هشت یک</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="pills-eight2-tab" data-toggle="pill" href="#pills-eight2" role="tab" aria-controls="pills-contact" aria-selected="false">هشت دو</a>
            </li>
            <li class="nav-item">
             <a class="nav-link" id="pills-eight3-tab" data-toggle="pill" href="#pills-eight3" role="tab" aria-controls="pills-contact" aria-selected="false">هشت سه</a>
         </li>
         <li class="nav-item">
          <a class="nav-link" id="pills-eight4-tab" data-toggle="pill" href="#pills-eight4" role="tab" aria-controls="pills-contact" aria-selected="false">هشت چهار</a>
      </li>
      <li class="nav-item">
       <a class="nav-link" id="pills-eight5-tab" data-toggle="pill" href="#pills-eight5" role="tab" aria-controls="pills-contact" aria-selected="false">هشت پنج</a>
   </li>
   <li class="nav-item">
    <a class="nav-link" id="pills-eight6-tab" data-toggle="pill" href="#pills-eight6" role="tab" aria-controls="pills-contact" aria-selected="false">هشت شش</a>
</li>
        </ul>
        <div class="tab-content my-5" id="pills-tabContent2">
            <div class="tab-pane fade show active" id="pills-all" role="tabpanel" aria-labelledby="pills-all-tab">
                <div class="row">
                    <div class=" col-md-2 my-2 text-center">
                       <div class="flex__column">
                        <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                        <span>
                            رضا حسینی راد
                        </span>
                       </div>
                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                         <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                         <span>
                             رضا حسینی راد
                         </span>
                        </div>
                     </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>

                </div>
            </div>
            <div class="tab-pane fade" id="pills-eight1" role="tabpanel" aria-labelledby="pills-eight1-tab"><div class="row">
                   
                   
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>

                </div></div>
            <div class="tab-pane fade" id="pills-eight2" role="tabpanel" aria-labelledby="pills-eight2-tab"><div class="row">
                   
                   
                    
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>

                </div></div>
            <div class="tab-pane fade" id="pills-eight3" role="tabpanel" aria-labelledby="pills-eight3-tab"><div class="row">
                   
                    
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>

                </div></div>
            <div class="tab-pane fade" id="pills-eight4" role="tabpanel" aria-labelledby="pills-eight4-tab"><div class="row">
                    <div class=" col-md-2 my-2 text-center">
                       <div class="flex__column">
                        <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                        <span>
                            رضا حسینی راد
                        </span>
                       </div>
                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                         <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                         <span>
                             رضا حسینی راد
                         </span>
                        </div>
                     </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>

                </div></div>
            <div class="tab-pane fade" id="pills-eight5" role="tabpanel" aria-labelledby="pills-eight5-tab"><div class="row">
                    
                   
                   
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>

                </div></div>
            <div class="tab-pane fade" id="pills-eight6" role="tabpanel" aria-labelledby="pills-eight6-tab"><div class="row">
                    <div class=" col-md-2 my-2 text-center">
                       <div class="flex__column">
                        <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                        <span>
                            رضا حسینی راد
                        </span>
                       </div>
                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                         <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                         <span>
                             رضا حسینی راد
                         </span>
                        </div>
                     </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>
                    <div class=" col-md-2 my-2 text-center">
                        <div class="flex__column">
                            <img src=" {{route('BaseUrl')}}/Pannel/assets/images/0150784058.jpg " height="100" width="75" alt="">
                            <span>
                                رضا حسینی راد
                            </span>
                           </div>                    </div>

                </div></div>
         
        </div>
    </div>
</div>
  </div>
</div>
  </div>
 </div>
</div>



@endsection


@section('css')
    <style>
    .flex__column{
        display: flex;
    flex-direction: column;
    align-items: center;
    border: 1px solid #d6d1d1;
    background: #fff;
    box-shadow: 1px 7px 22px 3px #8e909f8f;
    border-radius: 10px;
    padding: 10px;
    cursor: default!important;
    }

    .flex__column:hover{
        box-shadow: 1px 7px 22px 3px #0027ff52;
    }

    .flex__column > span{
        margin-top: 7px;
    }
    </style>
@endsection